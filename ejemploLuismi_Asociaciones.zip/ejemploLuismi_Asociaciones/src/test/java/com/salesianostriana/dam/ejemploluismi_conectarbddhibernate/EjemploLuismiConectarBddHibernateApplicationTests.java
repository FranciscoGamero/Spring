package com.salesianostriana.dam.ejemploluismi_conectarbddhibernate;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EjemploLuismiConectarBddHibernateApplicationTests {

	@Test
	void contextLoads() {
	}

}
