package com.salesianostriana.dam.ejemploluismi_asociaciones;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EjemploLuismiConectarBddHibernateApplication {

	public static void main(String[] args) {
		SpringApplication.run(EjemploLuismiConectarBddHibernateApplication.class, args);
	}

}
