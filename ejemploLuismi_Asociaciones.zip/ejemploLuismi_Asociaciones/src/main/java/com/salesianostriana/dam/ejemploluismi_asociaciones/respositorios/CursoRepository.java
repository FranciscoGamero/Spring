package com.salesianostriana.dam.ejemploluismi_asociaciones.respositorios;

import org.springframework.data.jpa.repository.JpaRepository;

import com.salesianostriana.dam.ejemploluismi_asociaciones.modelo.Curso;

public interface CursoRepository extends JpaRepository<Curso, Long>{

}
