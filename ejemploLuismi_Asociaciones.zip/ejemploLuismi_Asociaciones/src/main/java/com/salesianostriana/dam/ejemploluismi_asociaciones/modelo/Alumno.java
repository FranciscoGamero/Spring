package com.salesianostriana.dam.ejemploluismi_asociaciones.modelo;



import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@NoArgsConstructor @AllArgsConstructor
@Data
@Table(name ="alumnado")
public class Alumno {

	@Id @GeneratedValue //Esto hace que la id se genere sola en la BDD, se deja asi que por defecto usa el AUTO
	private long id;
	
	@Column(columnDefinition = "VARCHAR(100)")
	private String nombre;
	private String apellidos;
	//@Column(updatable = false) /*Por si queremos que no se pueda modificar*/
	//Hacer
	private String email;
	
	@ManyToOne
	private Curso curso;
	
	public Alumno(String nombre, String apellidos, String email) {
		super();
		this.nombre = nombre;
		this.apellidos = apellidos;
		this.email = email;
	}

	
}
