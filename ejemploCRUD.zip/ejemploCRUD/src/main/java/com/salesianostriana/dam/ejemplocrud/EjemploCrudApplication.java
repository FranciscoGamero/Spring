package com.salesianostriana.dam.ejemplocrud;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EjemploCrudApplication {

	public static void main(String[] args) {
		SpringApplication.run(EjemploCrudApplication.class, args);
	}

}
