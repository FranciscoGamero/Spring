package com.salesianostriana.dam.ejemplocrud;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EjemploCrudApplicationTests {

	@Test
	void contextLoads() {
	}

}
